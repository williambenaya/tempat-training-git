import java.util.Scanner;

public class Main {

	public Main() {
//		// TODO Auto-generated constructor stub
////		System.out.println("Test");
//		String text = "saya makan nasi";
//		String text2 = "SAYA MAKAN NASI";
//		System.out.println(text.charAt(2));
//		System.out.println(text.compareTo("Saya makan nasi"));
//		System.out.println(text.compareToIgnoreCase("SAYA MAKAN bubur"));
//		System.out.println(text.contains("k"));
//		System.out.println(text.contentEquals("Saya makan nasi"));
//		System.out.println(text.contentEquals(text2));
//		System.out.println(text.endsWith("nasi"));
//		System.out.println(text.startsWith("S"));
//		System.out.println(text.equals("Saya makan nasi"));
//		System.out.println(text.equalsIgnoreCase("SAYA MAKAN NASI"));
//		System.out.println(text.isEmpty());
//		System.out.println(text.length());
//		System.out.println(text.toLowerCase());
//		System.out.println(text.toUpperCase());
//		System.out.println(text.toCharArray());
//		char[] arr = text.toCharArray();
//		System.out.println(text.replace('a', 'u'));
//		System.out.println(text.replace("nasi", "bubur"));
////		System.out.println(text.replaceAll("Saya makan nasi", "Saya tidur"));
////		System.out.println(text.split("f"));
		
//		int angka = 27;
//		System.out.println(Math.pow(10, angka));
//		System.out.println(Math.sqrt(angka));
//		System.out.println(Math.cbrt(angka));
//		System.out.println(Math.cos(1));
//		System.out.println(Math.sin(1));
//		System.out.println(Math.tan(1));
//		System.out.println(Math.asin(1));
//		System.out.println(Math.acos(1));
//		System.out.println(Math.atan(1));
//		System.out.println(Math.floor(2.5));
//		System.out.println(Math.round(2.7));
//		System.out.println(Math.ceil(2.05));
		
		// 2.5 >= 0.5 = 3
		//2.4 <0.4 = 2
//		System.out.println(Math.log(10));
//		int angka2 = (int) (1 + Math.round(Math.random()));
//		System.out.println(angka2);
		
//		String kalimat = "223";
//		Integer angka = 35;
//		System.out.println(angka.equals(2));
//		System.out.println(angka.compareTo(4));
//		System.out.println(angka.parseInt(kalimat) + angka);
//		System.out.println(angka.sum(3, angka));
//		System.out.println(angka.floatValue());
//		System.out.println(angka.hashCode());
//		System.out.println(angka.toString() + 3);
//		System.out.println(angka.max(angka, 5));
//		System.out.println(angka.min(30, angka));
////		System.out.println(angka.reverse(30));
//		System.out.println(Integer.toOctalString(angka));
//		System.out.println(Integer.toHexString(angka));
//		
//		int angkaString = Integer.parseInt(kalimat);
//		System.out.println(angkaString + 4);
		
		Scanner scan = new Scanner(System.in);
		String nama, email, gender, address, validate;
		
		do {
			System.out.print("Input nama: ");
			nama = scan.nextLine();
			if(nama.length() < 5) {
				System.out.println("Nama minimal 5 karakter");
			}
			if(nama.length() > 20) {
				System.out.println("Nama maksimal 20 karakter");
			}
		}while(nama.length() < 5 || nama.length() > 20);
		do {
			System.out.print("Input Email: ");
			email = scan.nextLine();
			if(!email.contains("@")) {
				System.out.println("Email harus ada '@'");
			}else if(!email.endsWith(".com")) {
				System.out.println("Email harus diakhiri '.com'");
			}
		}while(!email.contains("@") || !email.endsWith("gmail.com"));
		do {
			System.out.print("Input Gender: ");
			gender = scan.nextLine();
			if(!gender.contentEquals("Male") && !gender.contentEquals("Female")){
				System.out.println("Gender harus Male atau Female");
			}
		}while(!gender.contentEquals("Male") && !gender.contentEquals("Female"));
		do {
			System.out.print("Input Address: ");
			address = scan.nextLine();
			if(address.length() < 5) {
				System.out.println("Adress harus lebih dari 5 karakter");
			}else if(!address.startsWith("Jalan")) {
				System.out.println("Address harus diawali kata 'Jalan'");
			}
		}while(address.length() < 5 || !address.startsWith("Jalan"));
		System.out.println("Success Input Data");
		do {
			System.out.println("Do you want to show data ? (Yes/No)");
			validate = scan.nextLine();
			if(!validate.equalsIgnoreCase("yes") && !validate.equalsIgnoreCase("no")) {
				System.out.println("harus yes atau no");
			}
		}while(!validate.equalsIgnoreCase("yes") && !validate.equalsIgnoreCase("no"));
		if(validate.equalsIgnoreCase("Yes")){
			System.out.println(nama);
			System.out.println(email);
			System.out.println(gender.toLowerCase());
			System.out.println(address);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}

}
