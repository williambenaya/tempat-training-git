
public class Mobil {
	
	String name;
	int topspeed;
	String manufacturer;
	int seatcount;
	
	public Mobil(String name, int topspeed, String manufacturer, int seatcount) {
		super();
		this.name = name;
		this.topspeed = topspeed;
		this.manufacturer = manufacturer;
		this.seatcount = seatcount;
	}
	
	//alt + shift + s
	//Generate constructor using fields
	
}
