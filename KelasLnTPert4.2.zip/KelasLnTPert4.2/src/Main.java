import java.util.ArrayList;
import java.util.Scanner;
import java.util.Vector;

public class Main {
	
	public Main() {
		// TODO Auto-generated constructor stub
//		Mobil car = new Mobil("Supra", 200, "Toyota", 2);
////		System.out.println(car.manufacturer);
////		System.out.println(car.name);
////		System.out.println(car.topspeed);
////		System.out.println(car.seatcount);
//		
//		Mobil[] cars = new Mobil[10];
//		cars[0] = new Mobil("Civic", 150, "Honda", 3);
//		cars[1] = new Mobil("Ertiga", 100, "Suzuki", 7);
//		cars[2] = new Mobil("Ayla", 100, "Toyota", 5);
//		
//		cars[0].topspeed = 200;
////		System.out.println(cars[0].manufacturer + " " + cars[0].name);
////		System.out.println(cars[1].manufacturer + " " + cars[1].name);
////		for(int a = 0; a < 3; a++) {
////			System.out.println(cars[a].name);
////			System.out.println(cars[a].manufacturer);
////			System.out.println(cars[a].topspeed);
////			System.out.println(cars[a].seatcount);
////			System.out.println();
////		}
//		
//		ArrayList<Mobil> carlist = new ArrayList<Mobil>();
//		carlist.add(new Mobil("Civic", 150, "Honda", 3));
//		carlist.add(new Mobil("Supra", 200, "Toyota", 2));
//		carlist.add(new Mobil("Avanza", 100, "Toyota", 8));
//		
////		System.out.println(carlist.get(0).name);
////		System.out.println(carlist.get(1).name);
//		
//		Scanner scan = new Scanner(System.in);
//		
//		String carName;
//		int carSpeed;
//		String carManufacturer;
//		int carSeat;
//		
//		System.out.print("Name: ");
//		carName = scan.nextLine();
//		
//		System.out.print("Speed: ");
//		carSpeed = scan.nextInt();
//		scan.nextLine();
//		
//		System.out.print("Manufacturer: ");
//		carManufacturer = scan.nextLine();
//		
//		System.out.print("Seat: ");
//		carSeat = scan.nextInt();
//		scan.nextLine();
//		
//		carlist.add(new Mobil(carName, carSpeed, carManufacturer, carSeat));
//		
//		carlist.get(0).topspeed = 200;
//		carlist.get(0).name = "Civic Type R";
//		
//		carlist.get(1).seatcount = 1;
//		
//		carlist.remove(0);
//		
//		for(int a = 0; a < carlist.size(); a++) {
//			System.out.println(carlist.get(a).name);
//			System.out.println(carlist.get(a).manufacturer);
//			System.out.println(carlist.get(a).topspeed);
//			System.out.println(carlist.get(a).seatcount);
//			System.out.println();
//		}
		
		menu();
		switchMenu();
	}
	
	Scanner scan = new Scanner(System.in);
	Vector<Mobil> carlist = new Vector<>();
	int chooseMenu;
	
	void menu() {
		do {
			System.out.println("Car Dealer\n");
			System.out.println("1. Add new Car");
			System.out.println("2. View All Car");
			System.out.println("3. Update Car");
			System.out.println("4. Delete Car");
			System.out.println("5. Exit");
			System.out.print("Choose: ");
			chooseMenu = scan.nextInt();
			scan.nextLine();
		}while(chooseMenu < 1 || chooseMenu > 5);
	}

	void switchMenu() {
		switch(chooseMenu) {
		case 1:
			addCar();
			break;
		case 2:
			viewCar();
			break;
		case 3:
			updateCar();
			break;
		case 4:
			deleteCar();
			break;
		case 5:
			return;
		}
	}
	
	String carName, carManufac;
	int topSpeed, carSeat;
	
	void addCar() {
		System.out.println("Add new Car\n");
		
		System.out.print("Insert Car Name: ");
		carName = scan.nextLine();
		
		System.out.print("Insert Car Manufacturer: ");
		carManufac = scan.nextLine();
		
		System.out.print("Insert Car Top Speed: ");
		topSpeed = scan.nextInt();
		scan.nextLine();
		
		System.out.print("Insert Car Seat Count: ");
		carSeat = scan.nextInt();
		scan.nextLine();
		
		carlist.add(new Mobil(carName, topSpeed, carManufac, carSeat));
		System.out.println("\nSuccess Add Data");
		System.out.println("Press Enter to Continue...");
		scan.nextLine();
		
		menu();
		switchMenu();
	}
	
	void viewCar() {
		int carIndex;
		System.out.println("View Car\n");
		for(int a = 0; a < carlist.size(); a++) {
			System.out.println((a+1) + ". " + carlist.get(a).name);
		}
		
		System.out.print("\nChoose car number to view(0 to exit): ");
		carIndex = scan.nextInt();
		scan.nextLine();
		
		if(carIndex == 0) {
			System.out.println("Press Enter to Continue...");
			scan.nextLine();
			menu();
			switchMenu();
		}else {
			System.out.println("Name: " + carlist.get(carIndex-1).name);
			System.out.println("Manufacturer: " + carlist.get(carIndex-1).manufacturer);
			System.out.println("Top Speed: " + carlist.get(carIndex-1).topspeed);
			System.out.println("Seat Count: " + carlist.get(carIndex-1).seatcount);
			
			System.out.println("\nPress Enter to Continue...");
			scan.nextLine();
			menu();
			switchMenu();
		}
	}
	
	void updateCar() {
		int carIndex, carUpdate;
		System.out.println("Update Car\n");
		for(int a = 0; a < carlist.size(); a++) {
			System.out.println((a+1) + ". " + carlist.get(a).name);
		}
		
		System.out.print("\nChoose car number to update(0 to exit): ");
		carIndex = scan.nextInt();
		scan.nextLine();
		
		if(carIndex == 0) {
			System.out.println("Press Enter to Continue...");
			scan.nextLine();
			menu();
			switchMenu();
		}else {
			System.out.println("1. Name: " + carlist.get(carIndex-1).name);
			System.out.println("2. Manufacturer: " + carlist.get(carIndex-1).manufacturer);
			System.out.println("3. Top Speed: " + carlist.get(carIndex-1).topspeed);
			System.out.println("4. Seat Count: " + carlist.get(carIndex-1).seatcount);
			
			System.out.print("Choose What to Update: ");
			carUpdate = scan.nextInt();
			scan.nextLine();
			
			if(carUpdate == 1) {
				System.out.print("Insert New Car Name: ");
				carName = scan.nextLine();
				
				carlist.get(carIndex-1).name = carName;
			}else if(carUpdate == 2) {
				System.out.print("Insert New Car Manufacturer: ");
				carManufac = scan.nextLine();
				
				carlist.get(carIndex-1).manufacturer = carManufac;
			}else if(carUpdate == 3) {
				System.out.print("Insert New Car Top Speed: ");
				topSpeed = scan.nextInt();
				scan.nextLine();
				
				carlist.get(carIndex-1).topspeed = topSpeed;
			}else if(carUpdate == 4) {
				System.out.print("Insert Car Seat Count: ");
				carSeat = scan.nextInt();
				scan.nextLine();
				
				carlist.get(carIndex-1).seatcount = carSeat;
			}else {
				System.out.println("Wrong number");
			}
			System.out.println("Success Update Data");
			System.out.println("Press Enter to Continue...");
			scan.nextLine();
			menu();
			switchMenu();
		}
	}
	
	void deleteCar() {
		int carIndex;
		System.out.println("Delete Car\n");
		
		for(int a = 0; a < carlist.size(); a++) {
			System.out.println((a+1) + ". " + carlist.get(a).name);
		}
		
		System.out.print("\nChoose car number to delete(0 to exit): ");
		carIndex = scan.nextInt();
		scan.nextLine();
		
		if(carIndex == 0) {
			System.out.println("Press Enter to Continue...");
			scan.nextLine();
			menu();
			switchMenu();
		}else {
			carlist.remove(carIndex-1);
			System.out.println("Success Delete Data");
			
			System.out.println("Press Enter to Continue...");
			scan.nextLine();
			menu();
			switchMenu();
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}

}
