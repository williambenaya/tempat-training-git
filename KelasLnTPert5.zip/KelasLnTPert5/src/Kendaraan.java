
public class Kendaraan {
	
//	Object Oriented Programing
//	1. Inheritance v
//	2. Polymorphism
//	3. Encapsulation v
	
//	1. public
//	2. private
//	3. protected
	
	//getter setter
	
	//alt + shift + s - generate getter and setter
	
	//overiding
	//overloading
	
	private String nama, type, manufacturer;
	private int price, speed;
	
	public void testDrive(int price) {
		System.out.println("Anda mengetik angka: " + price);
	}
	
	public String getNama() {
		return nama;
	}

	public void setNama(String nama) {
		this.nama = nama;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	public Kendaraan(String nama, String type, String manufacturer, int price, int speed) {
		super();
		this.nama = nama;
		this.type = type;
		this.manufacturer = manufacturer;
		this.price = price;
		this.speed = speed;
	}

}
