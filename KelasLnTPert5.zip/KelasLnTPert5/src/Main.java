import java.util.Scanner;
import java.util.Vector;

public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
//		Kendaraan ken = new Kendaraan("mycar", "avanza", "toyota", 1000000, 100);
//		System.out.println(ken.getManufacturer());
//		ken.setManufacturer("honda");
//		System.out.println(ken.getManufacturer());
//		ken.setNama("yourcar");
//		System.out.println(ken.getNama());
//		ken.setPrice(100000000);
//		System.out.println(ken.getPrice());
//		
//		Scanner scan = new Scanner(System.in);
//		
//		String nama;
//		nama = scan.nextLine();
//		
//		ken.setNama(nama);
//		System.out.println(ken.getNama());
		
//		Mobil car = new Mobil("myCar1", "Xenia", "Daihatsu", 100000000, 120, 4, 1, "stereo");
//		System.out.println(car.getNama());
//		System.out.println(car.getSpeakertype());
//		car.setNama("Car1");
//		System.out.println(car.getNama());
//		car.setSpeakercount(2);
//		System.out.println(car.getSpeakercount());
//		
//		Motor tor = new Motor("Mymotorcycle", "Ninja", "Kawasaki", 23000000, 150, 2);
//		System.out.println(tor.getNama());
//		System.out.println(tor.getSeatcount());
//		tor.setNama("Motor1");
//		System.out.println(tor.getNama());
//		tor.setSeatcount(1);
//		System.out.println(tor.getSeatcount());
		
//		Vector<Mobil> cars = new Vector<>();
//		cars.add(new Mobil("myCar1", "Xenia", "Daihatsu", 100000000, 120, 4, 1, "stereo"));
//		cars.add(new Mobil("myCar2", "Xeniaa", "Daihatsu", 100000000, 120, 4, 1, "stereo"));
//		
//		System.out.println(cars.get(0).getNama());
//		System.out.println(cars.get(1).getNama());
//		
//		cars.get(1).setType("Luxio");
//		System.out.println(cars.get(1).getType());
//		
//		cars.remove(1);
		
		Vector<Kendaraan> kendaraan = new Vector<>();
		kendaraan.add(new Mobil("Kendaraan1", "Civic", "Honda", 1000000000, 200, 2, 4, "dolby"));
		kendaraan.add(new Motor("Kendaraan2", "Ninja", "Kawasaki", 50000000, 150, 1));
		
//		System.out.println(kendaraan.get(0).getNama());
//		System.out.println(kendaraan.get(0).getType());
//		System.out.println(kendaraan.get(0).getManufacturer());
//		System.out.println(((Mobil)kendaraan.get(0)).getDoorcount());
//		
//		kendaraan.get(0).setNama("Mobil1");
//		System.out.println(kendaraan.get(0).getNama());
//		
//		((Mobil)kendaraan.get(0)).setDoorcount(4);
//		System.out.println(((Mobil)kendaraan.get(0)).getDoorcount());
//		
//		System.out.println(kendaraan.get(1).getNama());
//		System.out.println(((Motor)kendaraan.get(1)).getSeatcount());
//		((Motor)kendaraan.get(1)).setSeatcount(2);
//		System.out.println(((Motor)kendaraan.get(1)).getSeatcount());

		
		for(int a = 0; a < kendaraan.size(); a++) {
			if(kendaraan.get(a) instanceof Mobil) {
				System.out.println(a+1);
				System.out.println(kendaraan.get(a).getNama());
				System.out.println(kendaraan.get(a).getType());
				System.out.println(kendaraan.get(a).getManufacturer());
				System.out.println(((Mobil)kendaraan.get(a)).getDoorcount());
				System.out.println(((Mobil)kendaraan.get(a)).getSpeakercount());
				System.out.println(((Mobil)kendaraan.get(a)).getSpeakertype());
				System.out.println();
			}else if(kendaraan.get(a) instanceof Motor){
				System.out.println(a+1);
				System.out.println(kendaraan.get(a).getNama());
				System.out.println(kendaraan.get(a).getType());
				System.out.println(kendaraan.get(a).getManufacturer());
				System.out.println(((Motor)kendaraan.get(a)).getSeatcount());
				System.out.println();
			}
		}
		
		((Mobil)kendaraan.get(0)).testDrive(100,2);
		((Motor)kendaraan.get(1)).testDrive(100, 2, 2);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}

}
