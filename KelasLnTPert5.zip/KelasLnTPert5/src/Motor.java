
public class Motor extends Kendaraan {

	private int seatcount;

	public void testDrive(int price, int num, int num2) {
		System.out.println("Anda mengetik angka: " + num + "," + num2 + "seharga: " + price);
	}
	
	public Motor(String nama, String type, String manufacturer, int price, int speed, int seatcount) {
		super(nama, type, manufacturer, price, speed);
		this.seatcount = seatcount;
	}

	public int getSeatcount() {
		return seatcount;
	}

	public void setSeatcount(int seatcount) {
		this.seatcount = seatcount;
	}
	
	
}
