package kelasLntPert1;

import java.util.Scanner;

public class Menu {

	Scanner scan = new Scanner(System.in);
	
	public Menu() {
		int angka = 0;
		String bookTitle = "", bookAuthor = "", bookGenre = "", bookLocation ="";
		int bookYear = 0;
		do {
			do {
				System.out.println("Toko Buku");
				System.out.println("1. Insert Buku");
				System.out.println("2. View Book");
				System.out.println("3. Exit");
				System.out.print("Input angka: ");
				angka = scan.nextInt();
				scan.nextLine();
			}while(angka < 1 && angka > 3);
			switch(angka) {
			case 1:
				System.out.println("\n\n\nInsert book\n\n");
				do {
					System.out.print("Input Book Title: ");
					bookTitle = scan.nextLine();
				}while(bookTitle.length() < 5 || bookTitle.length() > 15);
				do {
					System.out.print("Input Book Author: ");
					bookAuthor = scan.nextLine();
				}while(!bookAuthor.startsWith("Mr. ") && !bookAuthor.startsWith("Mrs. "));
				do {
					System.out.print("Input Book Year: ");
					bookYear = scan.nextInt();
					scan.nextLine();
				}while(bookYear < 2010 || bookYear > 2020);
				do {
					System.out.print("Input Book Genre: ");
					bookGenre = scan.nextLine();
				}while(!bookGenre.contentEquals("Romance") && !bookGenre.contentEquals("Fantasy") && !bookGenre.contentEquals("Action"));
				do {
					System.out.print("Book Location: ");
					bookLocation = scan.nextLine();
				}while(!bookLocation.contains("Street"));
				System.out.println("Insert book completed");
				System.out.println("Press enter to continue");
				scan.nextLine();
			break;
		case 2:
			System.out.println("View Book");
			System.out.println("Book Title: " + bookTitle);
			System.out.println("Book Author: " + bookAuthor);
			System.out.println("Book Year: " + bookYear);
			System.out.println("Book Genre: " + bookGenre);
			System.out.println("Book Location: "+ bookLocation);
			System.out.println("Press Enter to Continue...");
			scan.nextLine();
			break;
		case 3:
			return;
		}
	}while(angka != 3);
	}

}
