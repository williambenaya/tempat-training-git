package kelasLntPert1;

import java.util.Scanner;

public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
//		System.out.print("Hello World");
//		System.out.println("Hello Dunia");
//		System.out.printf("%s", "Hello Dunia");
//		Itung();
//		int angka = scan.nextInt();
//		int angka = 5;
//		System.out.println("Angka : " + angka + " angka");
//		angka = angka+10;
//		System.out.printf("Angka : %d", angka);
//		char huruf = 'a';
//		System.out.println("Huruf : " + huruf);
//		huruf = 'z';
//		System.out.printf("Huruf : %c", huruf);
//		boolean check = true;
//		check = false;
//		System.out.println(check);
//		float angka2 = (float) 5.5;
//		System.out.println("Angka : " + angka2);
//		System.out.printf("%.3f", angka2);
//		double angka3 = 5.5;
//		System.out.println(angka3);
//		angka3 = 7.8;
//		System.out.printf("%.2f", angka3);
//		String kalimat = "Besok Libur";
//		System.out.println("Kalimat : " + kalimat);
//		System.out.printf("%s\n", kalimat);
//		Scanner scan = new Scanner(System.in);
//		System.out.print("Input angka : ");
//		int angka;
//		angka = scan.nextInt();
//		scan.nextLine();
//		System.out.println(angka);
//		String kalimat;
//		System.out.print("Input text: ");
//		kalimat = scan.nextLine();
//		System.out.println(kalimat);
//		int angka = 7;
//		int angka2 = 10;
//		if(angka == 7) {
//			if(angka2 == 8) {
//				System.out.println("Ini angka 7 dan 8");
//			}else {
//				System.out.println("Ini angka 7 dan bukan 8");
//			}
//		}else {
//			System.out.println("Bukan angka");
//		}
//		String buah = "semangka";
//		if(buah == "semangka") {
//			System.out.println("ini semangka");
//		}
//		boolean cek = false;
//		int angka = 6;
//		if(!(angka == 5)) {
//			System.out.println("Ini salah");
//		}
//		int angka = 7;
//		double angka2 = 5.5;
//		float angka = (float) 5.5;
//		if(angka2 == 5.5) {
//			System.out.println("halo");
//		}
//		switch(angka) {
//		case 5.5:
//			System.out.println("halo");
//			break;
//		case "semangka":
//			System.out.println("hai");
//			break;
//		}
//		if(angka == 5) {
//			System.out.println("Ini angka 5");
//		}else if(angka == 6) {
//			System.out.println("Ini angka 6");
//		}else {
//			System.out.println("ini bukan angka 5 dan 6");
//		}
//		for(int a = 1; a <= 10; a++) {
//			for(int b = 1; b <= 10; b++) {
//				System.out.print("1");
//			}
//			System.out.println();
//		}
		
//		int angka2 = 5;
//		int angka3 = angka2++;
//		System.out.println(angka3);
//		int angka = 5;
//		do {
//			System.out.println(angka);
//			angka--;
//		}while(angka >= 0);
//		
//		System.out.println();
//		System.out.println(angka);
//		System.out.println();
//		
//		while(angka <= 5) {
//			System.out.println(angka);
//			angka++;
//		}
//		
//		System.out.println(angka);
//		String kalimat = "88";
//		Integer angka = 5;
//		int angka5 = Integer.parseInt(kalimat);
//
//		System.out.println(angka5+angka);
		
//		System.out.println(kalimat.charAt(6));
//		System.out.println((angka+angka5));
//		System.out.println(kalimat.length());
//		System.out.println(kalimat.startsWith("Budi"));
//		System.out.println(kalimat.endsWith("nasi"));
//		System.out.println(kalimat.contains("z"));
//		System.out.println(kalimat.contentEquals("budi"));
//		System.out.println(kalimat.toLowerCase());
//		System.out.println(kalimat.toUpperCase());
	}

//	void Itung() {
//		System.out.println("halo");
//	}
//	
//	Scanner scan = new Scanner(System.in);
	
	public static void main(String[] args) {
//		System.out.println("Hello World!");
//		Itung();
//		int angka = scan.nextInt();
		new Menu();
	}

}
