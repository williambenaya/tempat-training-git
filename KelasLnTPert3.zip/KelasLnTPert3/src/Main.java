import java.util.ArrayList;
import java.util.Scanner;
import java.util.Vector;

public class Main {

	void clear() {
		for(int a = 0; a < 30; a++) {
			System.out.println();
		}
	}
	
	public Main() {
		// TODO Auto-generated constructor stub
//		int angka[] = new int[100];
//		int angka2[] = {1,3,5,10};
//		System.out.println(angka2[2]);
//		angka2[0] = 7;
//		System.out.println(angka2[0]);
//		for(int a = 0; a < angka2.length; a++) {
//			System.out.println(angka2[a]);
//		}
//		angka[0] = 1;
//		System.out.println(angka[0]);
//		angka[1] = 2;
//		System.out.println(angka[1]);
//		String kata[] = new String[100];
//		String kata2[] = {"halo", "budi"};
//		System.out.println(kata2[0]);
//		Vector<Integer> number = new Vector<>();
//		number.add(5);
//		number.add(10);
//		number.add(100);
//		number.add(20);
//		number.set(2, 500);
//		number.set(1, 50);
//		number.remove(0);
//		number.remove(2);
//		number.clear();
////		System.out.println(number.get(1));
//		for(int b = 0; b < number.size(); b++) {
//			System.out.println(number.get(b));
//		}
//		Vector<String> kalimat = new Vector<>();
//		kalimat.add("halo");
//		kalimat.add("hai");
//		kalimat.add("hei");
//		kalimat.add("hoi");
//		kalimat.set(3, "halooo");
//		kalimat.set(0, "helo");
//		kalimat.remove(2);
//		kalimat.remove(1);
////		System.out.println(kalimat.get(1));
//		for(int a = 0; a < kalimat.size(); a++) {
//			System.out.println(kalimat.get(a));
//		}
//		ArrayList<String> list = new ArrayList<>();
//		list.add("besok");
//		list.add("kemarin");
//		list.set(0, "hari ini");
//		list.remove(0);
//		list.clear();
////		System.out.println(list.get(0));
//		for(int a = 0; a < list.size(); a++) {
//			System.out.println(list.get(a));
//		}
//		ArrayList<Integer> list2 = new ArrayList<>();
//		list2.add(2);
//		list2.set(0, 5);
//		list2.remove(0);
//		System.out.println(list2.get(0));
		Scanner scan = new Scanner(System.in);
		int chooseMenu, bookYear, chooseUpdate;
		String bookName, bookAuthor, bookPublisher;
		ArrayList<String> name = new ArrayList<>();
		ArrayList<Integer> year = new ArrayList<>();
		ArrayList<String> author = new ArrayList<>();
		ArrayList<String> publisher = new ArrayList<>();
		do {
			do {
				clear();
				System.out.println("BookStore");
				System.out.println("1. Add Book");
				System.out.println("2. View All Book");
				System.out.println("3. Update Book");
				System.out.println("4. Delete Book");
				System.out.println("5. Exit");
				System.out.print("Choose: ");
				chooseMenu = scan.nextInt();
				scan.nextLine();
			}while(chooseMenu < 1 || chooseMenu > 5);
			switch(chooseMenu) {
			case 1:
				clear();
				System.out.println("Add Book\n\n");
				do {
					System.out.print("Insert book name: ");
					bookName = scan.nextLine();
				}while(bookName.length() < 5 || bookName.length() > 15);
				do {
					System.out.print("Insert book year: ");
					bookYear = scan.nextInt();
					scan.nextLine();
				}while(bookYear < 2000 || bookYear > 2020);
				do {
					System.out.print("Insert book author: ");
					bookAuthor = scan.nextLine();
				}while(!(bookAuthor.startsWith("Mr. ") || bookAuthor.startsWith("Mrs. ")));
				do {
					System.out.print("Insert book publisher(start with PT. ): ");
					bookPublisher = scan.nextLine();
				}while(!bookPublisher.startsWith("PT. "));
				name.add(bookName);
				year.add(bookYear);
				author.add(bookAuthor);
				publisher.add(bookPublisher);
				System.out.println("\nSuccess Add New Book\n");
				System.out.println("Press Enter to Continue...");
				scan.nextLine();
				break;
			case 2:
				clear();
				if(name.isEmpty()) {
					System.out.println("There is no Book yet\n");
					System.out.println("Please insert book first!\n");
				}else {
					System.out.println("View Book\n\n");
					for(int a = 0; a < name.size(); a++) {
						System.out.println((a+1) + ". " + name.get(a));
						System.out.println("Year: " + year.get(a));
						System.out.println("Author: " + author.get(a));
						System.out.println("Publisher: " + publisher.get(a));
						System.out.println("");
					}
				}
				System.out.println("Press Enter to Continue...");
				scan.nextLine();
				break;
			case 3:
				clear();
				if(name.isEmpty()) {
					System.out.println("There is no Book yet\n");
					System.out.println("Please insert book first!\n");
				}else {
					System.out.println("Update Book\n\n");
					
					System.out.print("Insert Book Name to Update: ");
					bookName = scan.nextLine();
					int x = name.indexOf(bookName);
					if(x == -1) {
						System.out.println("\nThere is no book named " + bookName);
					}else {
						do {
							System.out.println("\nWhat do you want to update");
							System.out.println("1. Book Name");
							System.out.println("2. Year");
							System.out.println("3. Author");
							System.out.println("4. Publisher");
							System.out.print("Choose: ");
							chooseUpdate = scan.nextInt();
							scan.nextLine();
						}while(chooseUpdate < 1 || chooseUpdate > 4);
						System.out.println();
						switch(chooseUpdate) {
						case 1:
							do {
								System.out.print("Insert new book name: ");
								bookName = scan.nextLine();
							}while(bookName.length() < 5 || bookName.length() > 15);
							name.set(x, bookName);
							System.out.println();
							System.out.println("Book Name successfully updated\n");
							break;
						case 2:
							do {
								System.out.print("Insert new book year: ");
								bookYear = scan.nextInt();
								scan.nextLine();
							}while(bookYear < 2000 || bookYear > 2020);
							year.set(x, bookYear);
							System.out.println();
							System.out.println("Book Year successfully updated\n");
							break;
						case 3:
							do {
								System.out.print("Insert new book author: ");
								bookAuthor = scan.nextLine();
							}while(!(bookAuthor.startsWith("Mr. ") || bookAuthor.startsWith("Mrs. ")));
							author.set(x, bookAuthor);
							System.out.println();
							System.out.println("Book Author successfully updated\n");
							break;
						case 4:
							do {
								System.out.print("Insert book publisher(start with PT. ): ");
								bookPublisher = scan.nextLine();
							}while(!bookPublisher.startsWith("PT. "));
							publisher.set(x, bookPublisher);
							System.out.println();
							System.out.println("Book Publisher succesfully updated\n");
							break;
						}
					}
				}
				System.out.println("Press Enter to Continue...");
				scan.nextLine();
				break;
			case 4:
				clear();
				if(name.isEmpty()) {
					System.out.println("There is no Book yet\n");
					System.out.println("Please insert book first!\n");
				}else {
					System.out.println("Delete Book\n\n");
					
					System.out.print("Insert Book Name to Delete: ");
					bookName = scan.nextLine();
					int z = name.indexOf(bookName);
					if(z == -1) {
						System.out.println("\nThere is no book named " + bookName);
					}else {
						name.remove(z);
						year.remove(z);
						author.remove(z);
						publisher.remove(z);
						System.out.println("\nBook successfully deleted\n");
					}
				}
				System.out.println("Press Enter to Continue...");
				scan.nextLine();
				break;
			case 5:
				clear();
				System.out.println("Thank you for reading");
				return;
			}
		}while(chooseMenu != 5);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}

}
